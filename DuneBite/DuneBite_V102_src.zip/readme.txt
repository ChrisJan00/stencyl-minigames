DuneBite V1.00
--------------

This game was made during the Global Game Jam 2012 in Berlin.  We've had a blast of a time, and thanks specially to the organizators.
It's a flash game made with Stencyl,  concept & sounds by Thorsten Wiedermann, graphics by Michael Hussinger, coding by Christiaan Janssen.

Enjoy!
29th January 2012